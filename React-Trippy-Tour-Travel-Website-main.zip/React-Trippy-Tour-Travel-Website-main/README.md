# React-Trippy-Tour-Travel-Website

[<img alt="React Website Tutorial Tour & Travel" width="100%" src="https://github.com/tech2etc/Youtube-Tutorials/blob/main/React-Trippy-Tour-Travel-Website.PNG?raw=true" />](https://www.youtube.com/c/Tech2etc/videos)

Hi everyone, welcome to our new react js website tutorial. In this tutorial, We will create a responsive tour and travel website using react js.

This is an empty react js template.

Without wasting your time, let's see what react js actually is...
- React is a JavaScript library for building user-friendly interfaces.
- It is Used to build single-page applications.
- Also, it allows us to create reusable UI components.

# Setup
1. Open Your VS Code.
2. Download this project.
3. Drag and drop this project inside VS code.
4. Open a terminal & run this command.
 run ```npm i && npm start```
 
Get the full source code from [here1](https://www.buymeacoffee.com/tech2etc/e/85299).
Get the full source code from [here2](https://ko-fi.com/s/7f02c9c3fd).
